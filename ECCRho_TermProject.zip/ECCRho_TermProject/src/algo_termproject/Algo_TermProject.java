/*
 *
 *
 *
 * authors@ Simerpreet & Ankit 
 * 
 * 
 */
package algo_termproject;

import java.math.BigInteger;

import java.util.Arrays;

public class Algo_TermProject {

    /* 1. Implementing mul Method */
    
    public static BigInteger[] mul(BigInteger[] a1, BigInteger[] a2, BigInteger d, BigInteger p) {
			
            BigInteger x1 = a1[0];
            BigInteger y1 = a1[1];

            BigInteger x2 = a2[0];
            BigInteger y2 = a2[1];


            BigInteger x1y2 = (x1.multiply(y2)).mod(p);
            BigInteger x2y1 = (x2.multiply(y1)).mod(p);

            BigInteger y1y2 = (y1.multiply(y2)).mod(p);
            BigInteger x1x2 = (x1.multiply(x2)).mod(p);

            // Numerators 
            BigInteger sumx1y2x2y1 = (x1y2.add(x2y1)).mod(p);
            BigInteger suby1y2x1x2 = (y1y2.subtract(x1x2)).mod(p);

            BigInteger mulFactor = d.multiply(x1).multiply(x2).multiply(y1).multiply(y2);//.mod(p);

            BigInteger leftDeno = (BigInteger.ONE.add(mulFactor).mod(p));
            BigInteger righttDeno = (BigInteger.ONE.subtract(mulFactor).mod(p));

            BigInteger x3 = sumx1y2x2y1.multiply(leftDeno.modInverse(p)).mod(p);
            BigInteger y3 = suby1y2x1x2.multiply(righttDeno.modInverse(p)).mod(p);

            BigInteger[] a3 = new BigInteger[]{x3, y3};


            return a3;
		
	}
     /* 2. Implementing exp Method  */
	
	public static BigInteger[] exp(BigInteger[] a, BigInteger m, BigInteger d, BigInteger p) {
		
            BigInteger[] b = new BigInteger[]{BigInteger.ZERO, BigInteger.ONE};
            try {

               for (int i=m.bitLength()-1;i>=0;i--) {               
                   b = mul(b, b, d, p);
                   if(m.testBit(i)) {
                       b = mul(b, a, d, p);
                   }
               }
            } catch (Exception e) {
                System.out.println(e);
            }
            return b;	
	}
	
         /* 3. Implementing rho Method */ 
        public static void new_ZAlphaBeta(BigInteger[] z, BigInteger[] a, BigInteger[] b, BigInteger d,
            BigInteger p, BigInteger[] alpha, BigInteger[] beta, BigInteger n) {

            int caseValue = z[0].mod(new BigInteger("3")).intValue();
            
            BigInteger[] output = new BigInteger[2];
            
            switch (caseValue){
                case 0:
                    output  = mul(z, b, d, p);
                    z[0] = output[0];
                    z[1] = output[1];
                    alpha[0] = (alpha[0].add(BigInteger.ONE)).mod(n);
                    break;
                case 1:  
                    output  = mul(z, z, d, p);
                    z[0] = output[0];
                    z[1] = output[1];
                    alpha[0] = (alpha[0].multiply(new BigInteger("2"))).mod(n);
                    beta[0] = (beta[0].multiply(new BigInteger("2"))).mod(n);    
                    break;    
                case 2:
                    output  = mul(z, a, d, p);
                    z[0] = output[0];
                    z[1] = output[1];
                    beta[0] = (beta[0].add(BigInteger.ONE)).mod(n);
                    break;
              } 
        }

        public static BigInteger[] rho(BigInteger[] a, BigInteger[] b, BigInteger d, BigInteger p, BigInteger n){
            BigInteger[] z = new BigInteger[]{BigInteger.ZERO, BigInteger.ONE};
            BigInteger[] Z = new BigInteger[]{BigInteger.ZERO, BigInteger.ONE};
            BigInteger m = BigInteger.ONE;
            BigInteger ZERO = BigInteger.ZERO;
            int k =1;
            
            BigInteger[] alpha = new BigInteger[] { ZERO };
            BigInteger[] beta =  new BigInteger[] { ZERO };
            
            BigInteger[] Alpha = new BigInteger[] { ZERO };
            BigInteger[] Beta =  new BigInteger[] { ZERO };
                   
            try {
              
              while(true) {  

                new_ZAlphaBeta(z, a, b, d, p, alpha, beta, n);  
                
                new_ZAlphaBeta(Z, a, b, d, p, Alpha, Beta, n);
                new_ZAlphaBeta(Z, a, b, d, p, Alpha, Beta, n);

           
                if(z[0].equals(Z[0]) && z[1].equals(Z[1])) {
                    break;
                } 
                else {
                    k++;
                }
            }
            
            BigInteger Bb = Beta[0].subtract(beta[0]).mod(n);
            BigInteger Aa = alpha[0].subtract(Alpha[0]).mod(n);
            m = Bb.multiply(Aa.modInverse(n)).mod(n);  
            } catch (Exception e) {
               System.out.println(e);  
            }
           
          
           return new BigInteger[]{m, BigInteger.valueOf(k)};
        }
                
         /* 4. Implementing check Method */
        public static long check(BigInteger[] a, BigInteger d, BigInteger p, BigInteger n){
            
            long rand = (long)(Math.random() * (n.intValue())); 
            BigInteger m = BigInteger.valueOf(rand);
            
            BigInteger[] expResult = exp(a, m, d, p);
            BigInteger[] rhoResult = rho(a, expResult, d, p, n);  
                
            if(m.equals(rhoResult[0])) {
                return rhoResult[1].longValue();
            } else {
                throw new RuntimeException("values didnt match");
            }
        }       
             
	public static void main (String args[]) {
            
            int N = 1000;
            long k = 0;
            
            BigInteger x1 = new BigInteger("12");
            BigInteger y1 = new BigInteger("61833");

            BigInteger d = new BigInteger("154");
            BigInteger n = new BigInteger("16339");
            
            
            BigInteger p = BigInteger.valueOf((long)Math.pow(2, 16) - 17);
            BigInteger[] a = new BigInteger[] {x1, y1};
            
            for (int i=0;i<N;i++) {
                long res = check(a, d, p, n);
                k += res; 
            }
            
            System.out.println("Computation of the average number <k> of steps needed to compute N random discrete logarithms");    
            System.out.println();
            System.out.println(" 4 . Long check method ");
            System.out.println(" Running result for p = 2^16 - 17, d = " + d.intValue() + ", n = " + n.intValue() + ", a = (" + a[0].intValue() + ", " + a[1].intValue() + ")" );
            
            System.out.println("Average of 1000 Iterations  <k>  :" +   k/1000);
            
            System.out.println();
            
            /* 5 a */
            
            x1 = new BigInteger("5");
            y1 = new BigInteger("261901");

            d = new BigInteger("294");
            n = new BigInteger("65717");
            
            
            p = BigInteger.valueOf((long)Math.pow(2, 18) - 5);
            a = new BigInteger[] {x1, y1};
            k = 0;
            for (int i=0;i<N;i++) {
                long res = check(a, d, p, n);
                k += res; 
            }
            System.out.println(" 5a).long check method :  ");
            System.out.println(" Running result for p = 2^18 - 5, d = " + d.intValue() + ", n = " + n.intValue() + ", a = (" + a[0].intValue() + ", " + a[1].intValue() + ")" );
            
            System.out.println("Average of 1000 Iterations <k>  :" +   k/1000);
            
            System.out.println();
            
            /* 5 b */
            
            x1 = new BigInteger("3");
            y1 = new BigInteger("111745");

            d = new BigInteger("47");
            n = new BigInteger("262643");
            
            
            p = BigInteger.valueOf((long)Math.pow(2, 20) - 5);
            a = new BigInteger[] {x1, y1};
            k = 0;
            
            for (int i=0;i<N;i++) {
                long res = check(a, d, p, n);
                k += res; 
            }
            
            System.out.println(" 5b).long check method : ");
            System.out.println("  Running result for p = 2^20 - 5, d = " + d.intValue() + ", n = " + n.intValue() + ", a = (" + a[0].intValue() + ", " + a[1].intValue() + ")" );
            
            System.out.println("Average of 1000 Iterations <k>  :" +   k/1000);
            
            System.out.println();
            
            /*5 c */ 
            
            x1 = new BigInteger("4");
            y1 = new BigInteger("85081");

            d = new BigInteger("314");
            n = new BigInteger("1049497");
            
            
            p = BigInteger.valueOf((long)Math.pow(2, 22) - 17);
            a = new BigInteger[] {x1, y1};
            k = 0;
            
            for (int i=0;i<N;i++) {
                long res = check(a, d, p, n);
                k += res; 
            }
            
            System.out.println(" 5c).long check method : ");
            System.out.println("  Running result for p = 2^22 - 17, d = " + d.intValue() + ", n = " + n.intValue() + ", a = (" + a[0].intValue() + ", " + a[1].intValue() + ")" );
            
            System.out.println("Average of 1000 Iterations <k>  :" +   k/1000);
            
            System.out.println();
            

            
            
           

	}
}
